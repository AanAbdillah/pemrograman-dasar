// Terdapat kesalahan

public class ConditionalAssignment {
    public static void main(String[] args) {
        String s = "filkom";
        String val = (s=="filkom")?"Brawijaya": "null";
        System.out.println(s+" "+val);
    }
}

// Terdapat pelanggaran konvensi

public class Variabel {
    public static void main(String[] args) {
        int nilai = 10;
        double nilai_2 = 5.3;
        int hasil;
        String s = "Belajar Java";
        System.out.println(nilai + nilai_2);
        System.out.println("Kita sedang " + s);
    }
}

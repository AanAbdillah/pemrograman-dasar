public class Assignment {
    public static void main(String[] args) {
        int num = 5; // num = 5

        // operator +=
        num += 5; // num = num + 5 = 10

        // operator -=
        num -= 5; // num = num - 5 = 5

        // operator *=
        num *= 5; // num = num * 5 = 25

        // operator /=
        num /= 5; // num = num / 5 = 5

        // operator %=
        num %= 5; // num = num % 5 = 0
    }
}

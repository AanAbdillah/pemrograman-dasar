public class Output {
    public static void main(String[] args) {
        System.out.print("Hello"); // print tanpa newline
        System.out.println("World"); // print dengan newline
        System.out.printf("Hey World%c", '!'); // print dengan format
    }
}

public class Aritmetika {
    public static void main(String[] args) {
        // numerik
        int x = 3;
        int y = 2;

        // int penjumlahan = x + y; // 5
        // int pengurangan = x - y; // 1

        // System.out.println(x + y);
        // System.out.println(pengurangan);

        // int perkalian = x * y; // 6
        // int pembagian = x / y; // 1

        // System.out.println(perkalian + " " + pembagian);

        // int modulo = x % y; // 1

        // x++; // increment => x = 4
        // y--; // decrement => y = 1

        // int prioritas = (x + y) * (x - y); // 15

        // String concat = "Hello " + "World"; // Hello World
    }
}

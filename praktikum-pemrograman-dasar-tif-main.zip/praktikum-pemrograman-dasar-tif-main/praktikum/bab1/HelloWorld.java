// main class
public class HelloWorld {
    // main method
    public static void main(String[] args) {
        System.out.println("Hello World"); // statement
        System.out.println("Halo Dunia"); // statement lain
    }
}

public class If {
    public static void main(String[] args) {
        int nilai = 80;

        if (nilai > 80) {
            // jika nilai di atas 80, maka print lulus
            System.out.println("Lulus");
        }

        // jika tidak, maka tidak melakukan apapun
    }
}

# Praktikum Pemrograman Dasar Teknik Informatika 2024
Repository source code modul praktikum dan slide ppt pemrograman dasar teknik informatika 2024. Untuk mengakses source code, bisa membuka code yang ada di repository secara manual melalui daftar isi di bawah atau dengan melakukan clone repository.    

## Daftar Isi
- [Source Code Modul Praktikum](https://github.com/nathakusuma/praktikum-pemrograman-dasar-tif/tree/main/modul)
  - [Bab 1 (Input, Output, Proses)](https://github.com/nathakusuma/praktikum-pemrograman-dasar-tif/tree/main/modul/bab1)
  - [Bab 2 (Seleksi Kondisi)](https://github.com/nathakusuma/praktikum-pemrograman-dasar-tif/tree/main/modul/bab1)
- [Source Code PPT Praktikum](https://github.com/nathakusuma/praktikum-pemrograman-dasar-tif/tree/main/praktikum)
  - [Bab 1 (Input, Output, Proses)](https://github.com/nathakusuma/praktikum-pemrograman-dasar-tif/tree/main/praktikum/bab1)
 
**Made with ❤️ by Tim Asisten Praktikum Teknik Informatika 2024**
